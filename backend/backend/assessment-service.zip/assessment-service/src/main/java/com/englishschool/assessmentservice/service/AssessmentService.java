package com.englishschool.assessmentservice.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.englishschool.assessmentservice.entity.Assessment;
import com.englishschool.assessmentservice.repository.AssessmentRepository;

@Service
@Transactional
public class AssessmentService {

    private final AssessmentRepository repository;
    private final RestTemplate restTemplate;

    // ✅ Un seul constructeur
    public AssessmentService(AssessmentRepository repository,
                             RestTemplate restTemplate) {
        this.repository = repository;
        this.restTemplate = restTemplate;
    }

    public Assessment save(Assessment entity) {
        return repository.save(entity);
    }

    public List<Assessment> findAll() {
        return repository.findAll();
    }

    public Assessment findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Assessment with ID " + id + " not found"));
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Assessment with ID " + id + " not found");
        }
        repository.deleteById(id);
    }

    // 🔥 Exemple d'appel vers resources-service via Eureka
    public String callResourcesService() {
        return restTemplate.getForObject(
                "http://RESOURCES-SERVICE/api/resources",
                String.class
        );
    }
}
